#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1

void delay (int);
void digitalWrite (char, char);
void pinMode (char pin, char modo);

